package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Database {
    private static Database instance;
    private Connection connection;
    private String url = "jdbc:mysql://localhost:3306/performtrack";
    private String user = "root";
    private String password = ""; 

    private Database() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            this.connection = DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException e) {
            throw new SQLException("JDBC Driver not found: " + e.getMessage());
        }
    }

    public static synchronized Database getInstance() throws SQLException {
        if (instance == null || instance.connection.isClosed()) {
            instance = new Database();
        }
        return instance;
    }

    public Connection getConnection() { return connection; }
}