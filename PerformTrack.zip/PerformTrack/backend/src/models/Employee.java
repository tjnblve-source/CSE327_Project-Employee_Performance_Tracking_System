package models;

import config.Database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Employee extends UserAccount {
    protected int employeeID;
    protected String name;
    protected int managerID;
    protected int departmentID;
    protected String jobTitle;
    protected String joiningDate;
    protected boolean promotionEligibilityStatus;

    public Employee(int userID, String username) {
        super(userID, username, "Employee");
        this.employeeID = userID;
        loadEmployeeData();
    }

    private void loadEmployeeData() {
        String query = "SELECT * FROM employee WHERE Employee_ID = ?";
        try {
            Connection conn = Database.getInstance().getConnection();
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, this.employeeID);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                this.name = rs.getString("Name");
                this.departmentID = rs.getInt("Department_ID");
                this.managerID = rs.getInt("Manager_ID");
                this.jobTitle = rs.getString("Job_Title");
                this.joiningDate = rs.getString("Joining_Date");
                this.promotionEligibilityStatus = rs.getBoolean("Promotion_Eligibility_Status");
            }
        } catch (SQLException e) {
            System.err.println("Error loading employee profile: " + e.getMessage());
        }
    }

    public void viewRatings() {
        String query = "SELECT Final_Score, Review_Period FROM appraisal WHERE Employee_ID = ?";
        try {
            Connection conn = Database.getInstance().getConnection();
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, this.employeeID);
            ResultSet rs = pstmt.executeQuery();

            System.out.println("--- Your Performance Ratings ---");
            while (rs.next()) {
                System.out.println("Period: " + rs.getString("Review_Period") + 
                                   " | Score: " + rs.getDouble("Final_Score"));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching ratings: " + e.getMessage());
        }
    }

    public void viewFeedback() {
        String query = "SELECT f.Comments, f.Rating_Value FROM feedback f " +
                       "JOIN appraisal a ON f.Appraisal_ID = a.Appraisal_ID " +
                       "WHERE a.Employee_ID = ?";
        try {
            Connection conn = Database.getInstance().getConnection();
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, this.employeeID);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                System.out.println("Rating: " + rs.getInt("Rating_Value") + "/5");
                System.out.println("Manager Comment: " + rs.getString("Comments"));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching feedback: " + e.getMessage());
        }
    }

    public void checkPromotionStatus() {
        if (this.promotionEligibilityStatus) {
            System.out.println("Status: You are currently ELIGIBLE for promotion.");
        } else {
            System.out.println("Status: Not yet eligible for promotion.");
        }
    }

    public int getEmployeeID() { return employeeID; }
    public String getName() { return name; }
    public String getJobTitle() { return jobTitle; }
}