package models;

import config.Database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class HumanResource extends Employee {

    public HumanResource(int userID, String username) {
        super(userID, username);
        this.role = "HR Admin";
    }

    public void registerEmployee(String name, String email, String jobTitle, int deptID) {
        String query = "INSERT INTO employee (Name, Email, Job_Title, Department_ID, Joining_Date) VALUES (?, ?, ?, ?, CURDATE())";
        try {
            Connection conn = Database.getInstance().getConnection();
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, jobTitle);
            pstmt.setInt(4, deptID);
            
            pstmt.executeUpdate();
            System.out.println("Employee " + name + " registered successfully.");
        } catch (SQLException e) {
            System.err.println("Error registering employee: " + e.getMessage());
        }
    }

    public void approvePromotion(int promotionID, String status) {
        String query = "UPDATE promotion SET Approval_Status = ? WHERE Promotion_ID = ?";
        try {
            Connection conn = Database.getInstance().getConnection();
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, status);
            pstmt.setInt(2, promotionID);
            
            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                System.out.println("Promotion " + promotionID + " status updated to: " + status);
            }
        } catch (SQLException e) {
            System.err.println("Error updating promotion: " + e.getMessage());
        }
    }

    public void generateAnalytics() {
        String query = "SELECT AVG(Final_Score) as AvgScore FROM appraisal";
        try {
            Connection conn = Database.getInstance().getConnection();
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                System.out.println("--- Workforce Analytics ---");
                System.out.println("Average Company Performance Score: " + rs.getDouble("AvgScore"));
            }
        } catch (SQLException e) {
            System.err.println("Error generating analytics: " + e.getMessage());
        }
    }
}