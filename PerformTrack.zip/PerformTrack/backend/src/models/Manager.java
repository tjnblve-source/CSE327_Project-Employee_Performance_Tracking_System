package models;

import config.Database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Manager extends Employee {
    private int managedDepartmentID;

    public Manager(int userID, String username) {
        super(userID, username);
        this.role = "Manager";
        loadManagerSpecificData();
    }

    private void loadManagerSpecificData() {
        String query = "SELECT Department_ID FROM manager WHERE Manager_ID = ?";
        try {
            Connection conn = Database.getInstance().getConnection();
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, this.employeeID);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                this.managedDepartmentID = rs.getInt("Department_ID");
            }
        } catch (SQLException e) {
            System.err.println("Error loading manager data: " + e.getMessage());
        }
    }

    public void addRatings(int targetEmployeeID, double finalScore, String reviewPeriod) {
        String query = "INSERT INTO appraisal (Employee_ID, Final_Score, Review_Period) VALUES (?, ?, ?)";
        try {
            Connection conn = Database.getInstance().getConnection();
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, targetEmployeeID);
            pstmt.setDouble(2, finalScore);
            pstmt.setString(3, reviewPeriod);
            pstmt.executeUpdate();
            System.out.println("Rating added successfully for Employee ID: " + targetEmployeeID);
        } catch (SQLException e) {
            System.err.println("Error adding ratings: " + e.getMessage());
        }
    }

    public void addFeedback(int appraisalID, String comments, int ratingValue) {
        String query = "INSERT INTO feedback (Appraisal_ID, Manager_ID, Comments, Rating_Value) VALUES (?, ?, ?, ?)";
        try {
            Connection conn = Database.getInstance().getConnection();
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, appraisalID);
            pstmt.setInt(2, this.employeeID);
            pstmt.setString(3, comments);
            pstmt.setInt(4, ratingValue);
            pstmt.executeUpdate();
            System.out.println("Feedback submitted successfully.");
        } catch (SQLException e) {
            System.err.println("Error adding feedback: " + e.getMessage());
        }
    }

    public void recordAchievement(int targetEmployeeID, String description, String date) {
        String query = "INSERT INTO achievement (Employee_ID, Achievement_Date, Description) VALUES (?, ?, ?)";
        try {
            Connection conn = Database.getInstance().getConnection();
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, targetEmployeeID);
            pstmt.setString(2, date);
            pstmt.setString(3, description);
            pstmt.executeUpdate();
            System.out.println("Achievement recorded.");
        } catch (SQLException e) {
            System.err.println("Error recording achievement: " + e.getMessage());
        }
    }

    public void reviewAttendance() {
        String query = "SELECT e.Name, a.Date, a.Status FROM attendance a " +
                       "JOIN employee e ON a.Employee_ID = e.Employee_ID " +
                       "WHERE e.Department_ID = ?";
        try {
            Connection conn = Database.getInstance().getConnection();
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, this.managedDepartmentID);
            ResultSet rs = pstmt.executeQuery();

            System.out.println("--- Department Attendance Report ---");
            while (rs.next()) {
                System.out.println("Employee: " + rs.getString("Name") + 
                                   " | Date: " + rs.getDate("Date") + 
                                   " | Status: " + rs.getString("Status"));
            }
        } catch (SQLException e) {
            System.err.println("Error reviewing attendance: " + e.getMessage());
        }
    }

    public int getManagedDepartmentID() { return managedDepartmentID; }
}