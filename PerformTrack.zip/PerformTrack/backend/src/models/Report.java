package models;

import config.Database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

public class Report {
    protected int reportID;
    protected int employeeID;
    protected int generatedBy;
    protected Timestamp timestamp;
    protected String dataSummary;

    protected double averageRating;
    protected int totalAchievements;
    protected double attendancePercentage;

    public Report() {}

    public Report(int reportID) {
        this.reportID = reportID;
        loadReportData();
    }

    private void loadReportData() {
        String query = "SELECT * FROM report WHERE Report_ID = ?";
        try {
            Connection conn = Database.getInstance().getConnection();
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, this.reportID);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                this.employeeID = rs.getInt("Employee_ID");
                this.generatedBy = rs.getInt("Generated_By");
                this.timestamp = rs.getTimestamp("Time_Stamp");
                this.averageRating = rs.getDouble("Average_Rating");
                this.totalAchievements = rs.getInt("Total_Achievements");
                this.attendancePercentage = rs.getDouble("Attendance_Percentage");
                
                this.dataSummary = "Base Report for Employee #" + employeeID + 
                                   " | Rating: " + averageRating + 
                                   " | Achievements: " + totalAchievements;
            }
        } catch (SQLException e) {
            System.err.println("Error loading report: " + e.getMessage());
        }
    }

    public String getDataSummary() {
        return this.dataSummary;
    }

    public void exportPDF() {
        System.out.println("Exporting PDF...");
        System.out.println("Content: " + getDataSummary());
        System.out.println("Timestamp: " + this.timestamp);
    }

    public double getWorkforceProductivity() {
        return (averageRating * 20) + (attendancePercentage * 0.5);
    }

    public int getReportID() { return reportID; }
    public Timestamp getTimestamp() { return timestamp; }
}