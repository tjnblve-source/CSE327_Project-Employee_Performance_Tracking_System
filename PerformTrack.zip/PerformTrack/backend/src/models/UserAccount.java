package models;

import config.Database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserAccount {
    protected int userID;
    protected String username;
    protected String password;
    protected String role;

    public UserAccount() {}

    public UserAccount(int userID, String username, String role) {
        this.userID = userID;
        this.username = username;
        this.role = role;
    }

    public boolean login(String inputUsername, String inputPassword) {
        String query = "SELECT * FROM user_account WHERE UserName = ? AND Password = ?";
        
        try {
            Connection conn = Database.getInstance().getConnection();
            PreparedStatement pstmt = conn.prepareStatement(query);
            
            pstmt.setString(1, inputUsername);
            pstmt.setString(2, inputPassword);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                this.userID = rs.getInt("User_ID");
                this.username = rs.getString("UserName");
                this.role = rs.getString("Role");
                System.out.println("Login Successful. Welcome, " + this.username + " (" + this.role + ")");
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Database error during login: " + e.getMessage());
        }
        
        System.out.println("Invalid credentials.");
        return false;
    }

    public void logout() {
        System.out.println("User " + this.username + " has logged out.");
        this.userID = 0;
        this.username = null;
        this.role = null;
    }
    
    public int getUserID() { return userID; }
    public String getUsername() { return username; }
    public String getRole() { return role; }
    
    public void setPassword(String password) { this.password = password; }
}