package patterns;

import config.Database;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class EmployeeNotificationService implements PromotionObserver {
    private int targetEmployeeID;

    public EmployeeNotificationService(int employeeID) {
        this.targetEmployeeID = employeeID;
    }

    @Override
    public void update(String message) {
        String sql = "INSERT INTO notifications (Employee_ID, Message) VALUES (?, ?)";
        try {
            Connection conn = Database.getInstance().getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, this.targetEmployeeID);
            pstmt.setString(2, message);
            pstmt.executeUpdate();
            System.out.println("Notification sent to Database for Employee #" + targetEmployeeID);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}