package patterns;

public interface PromotionObserver {
    void update(String message);
}