package patterns;

import models.Report;

public abstract class ReportDecorator extends Report {
    protected Report decoratedReport;
    public ReportDecorator(Report report) { this.decoratedReport = report; }
    
    @Override
    public String getDataSummary() {
        return decoratedReport.getDataSummary();
    }
}

class HighPerformerDecorator extends ReportDecorator {
    public HighPerformerDecorator(Report report) { super(report); }
    @Override
    public String getDataSummary() {
        return super.getDataSummary() + " | [BADGE: STAR PERFORMER]";
    }
}