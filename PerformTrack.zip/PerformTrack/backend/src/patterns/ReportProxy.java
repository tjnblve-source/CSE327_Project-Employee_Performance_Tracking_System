package patterns;

import models.Report;
import models.UserAccount;

public class ReportProxy extends Report {
    private Report realReport;
    private UserAccount currentUser;
    private int requestedReportID;

    /**
     * @param user The user attempting to access the report.
     * @param reportID The ID of the report requested from the DB.
     */
    public ReportProxy(UserAccount user, int reportID) {
        this.currentUser = user;
        this.requestedReportID = reportID;
    }

    @Override
    public String getDataSummary() {
        if (hasAccess()) {
            if (realReport == null) {
                System.out.println("Proxy: Access granted. Loading high-resolution report data from MySQL...");
                realReport = new Report(requestedReportID);
            }
            return realReport.getDataSummary();
        } else {
            return "ACCESS DENIED: You do not have the 'HR Admin' role required to view this report.";
        }
    }

    @Override
    public void exportPDF() {
        if (hasAccess()) {
            if (realReport == null) {
                realReport = new Report(requestedReportID);
            }
            realReport.exportPDF();
        } else {
            System.out.println("Proxy Alert: Unauthorized PDF export attempt by User ID " + currentUser.getUserID());
        }
    }

    private boolean hasAccess() {
        return currentUser != null && "HR Admin".equalsIgnoreCase(currentUser.getRole());
    }
}