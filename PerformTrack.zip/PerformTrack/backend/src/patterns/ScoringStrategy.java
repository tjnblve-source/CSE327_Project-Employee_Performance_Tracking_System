package patterns;

public interface ScoringStrategy {
    /**
     * Calculates the score based on raw performance data.
     * @param rawScore The base score provided by the manager in the PHP form.
     * @param attendance The attendance percentage from the database.
     * @return The final processed score.
     */
    double calculate(double rawScore, double attendance);
}