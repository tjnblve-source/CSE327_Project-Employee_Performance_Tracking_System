package patterns;

import models.*;
import config.Database;
import java.sql.*;

public class UserFactory {
    public static UserAccount getUser(int userID) {
        String query = "SELECT UserName, Role FROM user_account WHERE User_ID = ?";
        try {
            Connection conn = Database.getInstance().getConnection();
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, userID);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String name = rs.getString("UserName");
                String role = rs.getString("Role");
                return switch (role) {
                    case "Manager" -> new Manager(userID, name);
                    case "HR Admin" -> new HumanResource(userID, name);
                    default -> new Employee(userID, name);
                };
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }
}