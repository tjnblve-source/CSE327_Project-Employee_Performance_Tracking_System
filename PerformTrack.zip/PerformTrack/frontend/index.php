<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

$conn = new mysqli("localhost", "root", "", "performtrack");

$page = isset($_GET['page']) ? $_GET['page'] : 'login';

switch($page) {
    case 'login': include 'views/login.php'; break;
    case 'register': include 'views/register.php'; break;
    case 'dashboard':
        if (!isset($_SESSION['user_id'])) { header("Location: index.php?page=login"); exit(); }
        include 'views/dashboard.php';
        break;

    case 'appraisal_form':
        $employee_id = $_GET['id'] ?? '';
        include 'views/appraisal_form.php';
        break;

    case 'pending_appraisals':
        include 'views/pending.php';
        break;

    case 'process_achievement':
        if ($_SERVER["REQUEST_METHOD"] == "GET") {
            include 'views/employee_achievements.php';
        }
        else if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $emp_id = $_POST['emp_id'];
            $desc = $_POST['description'];

            $stmt = $conn->prepare("INSERT INTO achievement (Employee_ID, Description) VALUES (?, ?)");
            $stmt->bind_param("is", $emp_id, $desc);
            
            if ($stmt->execute()) {
                shell_exec("java -cp bin com.performtrack.Main logAchievement $emp_id");
                
                header("Location: index.php?page=dashboard&award=success");
                exit();
            }
        }
        break;

    case 'process_registration':
        $full_name = $_POST['full_name'];
        $email = $_POST['email'];
        $username = $_POST['username'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $role = $_POST['role'];

        $stmt = $conn->prepare("INSERT INTO user_account (UserName, Full_Name, Email, Password, Role) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $username, $full_name, $email, $password, $role);

        if ($stmt->execute()) {
            $new_user_id = $conn->insert_id;
            if ($role === 'Employee') {
                $joining_date = date('Y-m-d');
                $emp_stmt = $conn->prepare("INSERT INTO employee (Employee_ID, Name, Email, Joining_Date, Promotion_Eligibility_Status, Attendance_Percentage) VALUES (?, ?, ?, ?, 0, 100)");
                $emp_stmt->bind_param("isss", $new_user_id, $full_name, $email, $joining_date);
                $emp_stmt->execute(); 
            }
            header("Location: index.php?page=login&registration=success");
            exit();
        }
        break;

    case 'process_appraisal':
        $emp_id = $_POST['emp_id'];
        $score = $_POST['score'];
        $period = date("F Y");
        
        $att_res = $conn->query("SELECT Attendance_Percentage FROM employee WHERE Employee_ID = $emp_id");
        $att_data = $att_res->fetch_assoc();
        $attendance = $att_data['Attendance_Percentage'] ?? 0;

        $java_command = "java -cp bin com.performtrack.Main evaluate $score $attendance 2>&1";
        $java_output = shell_exec($java_command);
        
        $cleaned_output = ($java_output !== null) ? trim($java_output) : "";
        $new_status = (is_numeric($cleaned_output)) ? $cleaned_output : 0; 

        $stmt = $conn->prepare("INSERT INTO appraisal (Employee_ID, Final_Score, Review_Period) VALUES (?, ?, ?)");
        $stmt->bind_param("ids", $emp_id, $score, $period);
        
        if ($stmt->execute()) {
            $conn->query("UPDATE employee SET Promotion_Eligibility_Status = $new_status WHERE Employee_ID = $emp_id");
            header("Location: index.php?page=dashboard&status=evaluated");
            exit();
        }
        break;

    case 'approve_promotion':
        $id = $_GET['id'];
        $conn->query("UPDATE user_account SET Role = 'Senior Employee' WHERE User_ID = $id");
        $conn->query("UPDATE employee SET Promotion_Eligibility_Status = 0 WHERE Employee_ID = $id");
        shell_exec("java -cp bin com.performtrack.Main notifyPromotion $id");
        header("Location: index.php?page=dashboard&success=promoted");
        break;

    case 'reports':
        $user_role = $_SESSION['role'] ?? 'Manager';
        $report_data = shell_exec("java -cp bin com.performtrack.Main generateReport $user_role 2>&1");
        include 'views/reports.php'; 
        break;

    case 'logout':
        session_destroy();
        header("Location: index.php?page=login");
        exit();
        break;
}
?>