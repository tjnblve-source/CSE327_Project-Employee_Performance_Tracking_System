<link rel="stylesheet" href="css/style.css">
<div class="form-card">
    <div class="form-header">
        <h2>Performance Evaluation</h2>
        <p>You are evaluating Employee ID: <strong><?php echo htmlspecialchars($employee_id); ?></strong></p>
    </div>

    <form action="index.php?page=process_appraisal" method="POST">
        <input type="hidden" name="emp_id" value="<?php echo $_GET['id']; ?>">
        
        <div class="form-group">
            <label>Final Score (1-5)</label>
            <input type="number" name="score" step="0.1" min="1" max="5" required>
        </div>

        <div class="form-group">
            <label>Manager Comments</label>
            <textarea name="feedback" placeholder="Optional feedback..."></textarea>
        </div>

        <button type="submit" class="btn-submit">Save Appraisal</button>
    </form>
</div>