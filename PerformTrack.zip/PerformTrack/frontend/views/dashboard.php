<?php
$role = $_SESSION['role'] ?? 'Employee';
$user_id = $_SESSION['user_id'] ?? 0;
$full_name = $_SESSION['full_name'] ?? ($_SESSION['username'] ?? 'Team Member');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PerformTrack | <?php echo htmlspecialchars($role); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-dark: #003b46;
            --primary-light: #07575b;
            --accent-teal: #66a5ad;
            --bg-gray: #f4f7f6;
            --text-dark: #333;
            --white: #ffffff;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-gray);
            color: var(--text-dark);
            overflow: hidden;
        }

        .dashboard-wrapper {
            display: flex;
            height: 100vh;
            width: 100vw;
        }

        /* --- SHARED SIDEBAR --- */
        .sidebar {
            width: 260px;
            background: var(--primary-dark);
            color: var(--white);
            display: flex;
            flex-direction: column;
            flex-shrink: 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        }

        .logo-section {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .logo-section h2 {
            margin: 0;
            font-size: 22px;
            letter-spacing: 1.5px;
            font-weight: 600;
        }

        .nav-container {
            flex-grow: 1;
            padding: 20px 15px;
            overflow-y: auto;
        }

        .nav-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .nav-item {
            cursor: pointer;
            padding: 12px 15px;
            margin-bottom: 8px;
            border-radius: 8px;
            transition: all 0.3s ease;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: rgba(255,255,255,0.7);
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--white);
        }

        .nav-item.active {
            background: var(--primary-light);
            color: var(--white);
            font-weight: 600;
        }

        .main-container {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .topbar {
            height: 70px;
            background: var(--white);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            z-index: 10;
        }

        .welcome-text h1 {
            font-size: 18px;
            margin: 0;
            color: var(--primary-dark);
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 12px;
            padding-right: 20px;
            border-right: 1px solid #eee;
        }

        .user-info {
            text-align: right;
        }

        .user-info .name {
            display: block;
            font-weight: 600;
            font-size: 14px;
        }

        .user-info .role-tag {
            font-size: 11px;
            color: var(--primary-light);
            text-transform: uppercase;
            font-weight: bold;
            letter-spacing: 0.5px;
        }

        .avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-dark);
            border: 2px solid var(--bg-gray);
        }

        .logout-btn {
            background: #ff6b6b;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            font-size: 13px;
            transition: background 0.3s;
        }

        .logout-btn:hover {
            background: #ee5253;
        }

        .dashboard-content {
            padding: 40px;
            overflow-y: auto;
            flex-grow: 1;
        }
    </style>
</head>
<body>

    <div class="dashboard-wrapper">
        <aside class="sidebar">
            <div class="logo-section">
                <h2>PerformTrack</h2>
            </div>
            
            <nav class="nav-container">
                <ul class="nav-list">
                    <li onclick="location.href='index.php?page=dashboard'" class="nav-item <?php echo (!isset($_GET['page']) || $_GET['page'] == 'dashboard') ? 'active' : ''; ?>">
                        🏠 Dashboard Home
                    </li>

                    <?php if($role === 'Manager'): ?>
                        <li onclick="location.href='index.php?page=pending_appraisals'" class="nav-item">📝 Pending Appraisals</li>
                        <li onclick="location.href='index.php?page=reports'" class="nav-item">📊 Performance Reports</li>
                    <?php endif; ?>

                    <?php if($role === 'HR Admin'): ?>
                        <li onclick="location.href='index.php?page=register'" class="nav-item">➕ Register Personnel</li>
                    <?php endif; ?>
                    
                    <?php if($role === 'Employee'): ?>
                        <li onclick="location.href='index.php?page=process_achievement'" class="nav-item">🏆 My Achievements</li>
                    <?php endif; ?>
                </ul>
            </nav>
        </aside>

        <div class="main-container">
            <header class="topbar">
                <div class="welcome-text">
                    <h1>Welcome, <?php echo htmlspecialchars($full_name); ?></h1>
                </div>
                
                <div class="topbar-right">
                    <div class="user-profile">
                        <div class="user-info">
                            <span class="name"><?php echo htmlspecialchars($full_name); ?></span>
                            <span class="role-tag"><?php echo htmlspecialchars($role); ?></span>
                        </div>
                        <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($full_name); ?>&background=003b46&color=fff" class="avatar" alt="User Avatar">
                    </div>
                    <button class="logout-btn" onclick="location.href='index.php?page=logout'">Logout</button>
                </div>
            </header>

            <main class="dashboard-content">
                <?php 
                    switch ($role) {
                        case 'HR Admin':
                            include 'views/dashboards/hr.php';
                            break;
                        case 'Manager':
                            include 'views/dashboards/manager.php';
                            break;
                        default:
                            include 'views/dashboards/employee.php';
                            break;
                    }
                ?>
            </main>
        </div>

    </div>

</body>
</html>