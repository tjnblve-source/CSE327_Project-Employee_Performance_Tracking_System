<?php
$emp_id = $_SESSION['user_id'] ?? 0;
?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<div class="inner-content">
    
    <?php
    $notif_res = $conn->query("SELECT Message FROM notifications WHERE Employee_ID = $emp_id ORDER BY Created_At DESC LIMIT 1");
    if ($notif = $notif_res->fetch_assoc()): ?>
        <div id="notificationBar" style="display: flex; background: #e3f2fd; border-left: 5px solid #2196f3; padding: 18px; margin-bottom: 30px; border-radius: 10px; align-items: center; box-shadow: 0 4px 6px rgba(0,0,0,0.05);">
            <span style="margin-right: 15px; font-size: 24px;">🔔</span>
            <div style="flex-grow: 1;">
                <span style="display: block; font-weight: 600; color: #1565c0;">System Update</span>
                <span style="color: #333;"><?php echo htmlspecialchars($notif['Message']); ?></span>
            </div>
            <button onclick="this.parentElement.style.display='none'" style="cursor: pointer; border: none; background: none; font-size: 22px; color: #999;">&times;</button>
        </div>
    <?php endif; ?>

    <div class="stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 25px; margin-bottom: 35px;">
        
        <div class="stat-card" style="background: white; padding: 30px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); text-align: center; border-bottom: 4px solid #003b46;">
            <h3 style="color: #888; font-size: 14px; text-transform: uppercase; margin-bottom: 15px; font-weight: 600;">Overall Rating</h3>
            <?php
            $rating_res = $conn->query("SELECT AVG(Final_Score) as avg_score FROM appraisal WHERE Employee_ID = $emp_id");
            $rating_data = $rating_res->fetch_assoc();
            $display_score = $rating_data['avg_score'] ? round($rating_data['avg_score'], 1) : "N/A";
            ?>
            <p style="font-size: 3rem; font-weight: bold; color: #003b46; margin: 0;"><?php echo $display_score; ?></p>
            <span style="color: #bbb; font-size: 12px;">Scale: 1.0 - 5.0</span>
        </div>
        
        <div class="stat-card" style="background: white; padding: 30px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); text-align: center; border-bottom: 4px solid #07575b;">
            <h3 style="color: #888; font-size: 14px; text-transform: uppercase; margin-bottom: 15px; font-weight: 600;">Current Attendance</h3>
            <?php
            $att_res = $conn->query("SELECT Attendance_Percentage FROM employee WHERE Employee_ID = $emp_id");
            $att_data = $att_res->fetch_assoc();
            $attendance_val = $att_data['Attendance_Percentage'] ?? 0;
            ?>
            <p style="font-size: 3rem; font-weight: bold; color: #07575b; margin: 0;"><?php echo $attendance_val; ?>%</p>
            <span style="color: #bbb; font-size: 12px;">Target: 85%+</span>
        </div>

    </div>

    <div class="charts-container" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 30px;">
        
        <div class="chart-card" style="background: white; padding: 25px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.05);">
            <h3 style="color: #003b46; margin-bottom: 20px; font-size: 16px; border-left: 4px solid #003b46; padding-left: 15px;">Appraisal History</h3>
            <canvas id="performanceLineChart" style="max-height: 300px;"></canvas>
        </div>

        <div class="chart-card" style="background: white; padding: 25px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.05);">
            <h3 style="color: #003b46; margin-bottom: 20px; font-size: 16px; border-left: 4px solid #07575b; padding-left: 15px;">Punctuality Overview</h3>
            <canvas id="attendancePieChart" style="max-height: 300px;"></canvas>
        </div>
    </div>
</div>

<?php
$months = []; $scores = [];
$perf_res = $conn->query("SELECT Final_Score, Review_Period FROM appraisal WHERE Employee_ID = $emp_id ORDER BY Appraisal_ID ASC LIMIT 6");
while($p = $perf_res->fetch_assoc()) {
    $months[] = $p['Review_Period'];
    $scores[] = $p['Final_Score'];
}
?>

<script>
new Chart(document.getElementById('performanceLineChart').getContext('2d'), {
    type: 'line',
    data: {
        labels: <?php echo json_encode($months); ?>,
        datasets: [{
            label: 'Score',
            data: <?php echo json_encode($scores); ?>,
            borderColor: '#003b46',
            backgroundColor: 'rgba(0, 59, 70, 0.05)',
            fill: true,
            tension: 0.3,
            pointRadius: 5,
            pointBackgroundColor: '#07575b'
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true, max: 5 } }
    }
});
    
new Chart(document.getElementById('attendancePieChart').getContext('2d'), {
    type: 'pie',
    data: {
        labels: ['Present', 'Absent'],
        datasets: [{
            data: [<?php echo $attendance_val; ?>, <?php echo (100 - $attendance_val); ?>],
            backgroundColor: ['#07575b', '#e0e0e0'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { position: 'bottom' } }
    }
});
</script>