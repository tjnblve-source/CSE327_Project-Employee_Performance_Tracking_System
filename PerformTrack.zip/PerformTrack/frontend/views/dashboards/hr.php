<div class="inner-dashboard-content">
    <div style="margin-bottom: 35px; border-bottom: 2px solid #eee; padding-bottom: 15px;">
        <h1 style="color: #07575b; margin: 0; font-size: 24px;">HR Administrator Portal</h1>
        <p style="color: #666; margin: 5px 0 0 0;">Global workforce oversight and career milestone management.</p>
    </div>

    <div class="stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 35px;">
        
        <div class="stat-card" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); text-align: center;">
            <h4 style="color: #888; font-size: 12px; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 0.5px;">Total Personnel</h4>
            <?php
            $count_res = $conn->query("SELECT COUNT(*) as total FROM user_account");
            $count_data = $count_res->fetch_assoc();
            ?>
            <p style="font-size: 2.2rem; font-weight: bold; color: #003b46; margin: 0;"><?php echo $count_data['total']; ?></p>
        </div>

        <div class="stat-card" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); text-align: center;">
            <h4 style="color: #888; font-size: 12px; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 0.5px;">Promotable Staff</h4>
            <?php
            $eligible_count = $conn->query("SELECT COUNT(*) as total FROM employee WHERE Promotion_Eligibility_Status = 1");
            $eligible_data = $eligible_count->fetch_assoc();
            ?>
            <p style="font-size: 2.2rem; font-weight: bold; color: #2ecc71; margin: 0;"><?php echo $eligible_data['total'] ?? 0; ?></p>
        </div>

        <div class="stat-card" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); text-align: center; display: flex; flex-direction: column; justify-content: center;">
            <h4 style="color: #888; font-size: 12px; margin-bottom: 5px; text-transform: uppercase; letter-spacing: 0.5px;">System Status</h4>
            <div style="display: flex; align-items: center; justify-content: center; gap: 8px; color: #2ecc71; font-weight: bold;">
                <span style="height: 10px; width: 10px; background: #2ecc71; border-radius: 50%; display: inline-block;"></span>
                ONLINE
            </div>
        </div>
    </div>

    <div class="table-card" style="background: white; padding: 30px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.05);">
        <h3 style="margin-bottom: 20px; color: #003b46; font-size: 18px; border-left: 4px solid #07575b; padding-left: 15px;">📈 Career Milestone Oversight</h3>
        <table style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr style="background: #f8f9fa; text-align: left; border-bottom: 2px solid #eee;">
                    <th style="padding: 15px; color: #555; font-size: 13px;">Employee Name</th>
                    <th style="padding: 15px; color: #555; font-size: 13px;">Current Role</th>
                    <th style="padding: 15px; color: #555; font-size: 13px;">Eligibility Status</th>
                    <th style="padding: 15px; color: #555; font-size: 13px; text-align: center;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = "SELECT u.User_ID, u.Full_Name, u.Role, e.Promotion_Eligibility_Status 
                          FROM user_account u 
                          JOIN employee e ON u.User_ID = e.Employee_ID 
                          WHERE u.Role = 'Employee'";
                
                $result = $conn->query($query);

                if ($result && $result->num_rows > 0):
                    while($row = $result->fetch_assoc()): ?>
                    <tr style="border-bottom: 1px solid #f9f9f9; transition: 0.2s;" onmouseover="this.style.background='#fcfcfc'" onmouseout="this.style.background='transparent'">
                        <td style="padding: 15px; font-weight: 600; color: #333;"><?php echo htmlspecialchars($row['Full_Name']); ?></td>
                        <td style="padding: 15px; color: #666; font-size: 14px;"><?php echo htmlspecialchars($row['Role']); ?></td>
                        <td style="padding: 15px;">
                            <?php 
                            $is_eligible = ($row['Promotion_Eligibility_Status'] == 1);
                            $status_text = $is_eligible ? 'ELIGIBLE' : 'IN PROGRESS';
                            $bg_color = $is_eligible ? '#eafaf1' : '#fff4e5';
                            $text_color = $is_eligible ? '#2ecc71' : '#e67e22';
                            ?>
                            <span style="background: <?php echo $bg_color; ?>; color: <?php echo $text_color; ?>; padding: 6px 14px; border-radius: 20px; font-size: 11px; font-weight: bold; letter-spacing: 0.5px;">
                                <?php echo $status_text; ?>
                            </span>
                        </td>
                        <td style="padding: 15px; text-align: center;">
                            <?php if($is_eligible): ?>
                                <button onclick="approvePromotion(<?php echo $row['User_ID']; ?>)" 
                                        style="background: #003b46; color: white; border: none; padding: 9px 18px; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 13px; transition: 0.3s; font-family: inherit;">
                                    Approve Promotion
                                </button>
                            <?php else: ?>
                                <span style="color: #aaa; font-size: 12px; font-style: italic;">Awaiting Performance Targets</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; 
                else: ?>
                    <tr><td colspan="4" style="padding: 40px; text-align: center; color: #999;">No employee records found in the oversight system.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function approvePromotion(id) {
    if(confirm('Are you sure you want to promote this employee? This will update their role and trigger a system notification.')) {
        window.location.href = 'index.php?page=approve_promotion&id=' + id;
    }
}
</script>