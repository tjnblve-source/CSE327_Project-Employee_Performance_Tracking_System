<div class="inner-dashboard-content">
    <div style="margin-bottom: 35px; border-bottom: 2px solid #eee; padding-bottom: 15px;">
        <h1 style="color: #07575b; margin: 0; font-size: 24px;">Managerial Oversight</h1>
        <p style="color: #666; margin: 5px 0 0 0;">Evaluate team performance and recognize achievements.</p>
    </div>

    <div class="action-bar" style="margin-bottom: 30px; display: flex; gap: 15px;">
        <button onclick="document.getElementById('ratingModal').style.display='block'" 
                style="background: #003b46; color: white; padding: 12px 25px; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; display: flex; align-items: center; gap: 10px; transition: 0.3s;">
            <span>⭐</span> Quick Rating
        </button>
        <button onclick="document.getElementById('achievementModal').style.display='block'" 
                style="background: #07575b; color: white; padding: 12px 25px; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; display: flex; align-items: center; gap: 10px; transition: 0.3s;">
            <span>🏆</span> Award Achievement
        </button>
    </div>

    <div class="table-card" style="background: white; padding: 30px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.05);">
        <h3 style="margin-bottom: 20px; color: #003b46; font-size: 18px; border-left: 4px solid #003b46; padding-left: 15px;">Team Roster</h3>
        <table style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr style="text-align: left; border-bottom: 2px solid #f4f4f4;">
                    <th style="padding: 15px; color: #888; font-size: 13px; text-transform: uppercase;">ID</th>
                    <th style="padding: 15px; color: #888; font-size: 13px; text-transform: uppercase;">Employee Name</th>
                    <th style="padding: 15px; color: #888; font-size: 13px; text-transform: uppercase;">Email Contact</th>
                    <th style="padding: 15px; color: #888; font-size: 13px; text-transform: uppercase; text-align: center;">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = "SELECT User_ID, Full_Name, Email FROM user_account WHERE Role = 'Employee'";
                $result = $conn->query($query);

                if ($result && $result->num_rows > 0):
                    while($row = $result->fetch_assoc()): ?>
                    <tr style="border-bottom: 1px solid #f9f9f9; transition: 0.2s;" onmouseover="this.style.background='#fcfcfc'" onmouseout="this.style.background='transparent'">
                        <td style="padding: 15px; color: #777;">#<?php echo $row['User_ID']; ?></td>
                        <td style="padding: 15px; font-weight: 600; color: #333;"><?php echo htmlspecialchars($row['Full_Name']); ?></td>
                        <td style="padding: 15px; color: #666;"><?php echo htmlspecialchars($row['Email']); ?></td>
                        <td style="padding: 15px; text-align: center;">
                            <a href="index.php?page=appraisal_form&id=<?php echo $row['User_ID']; ?>" 
                               style="color: #66a5ad; text-decoration: none; font-weight: bold; padding: 8px 15px; border: 1px solid #66a5ad; border-radius: 5px; font-size: 13px; transition: 0.3s;">
                               Evaluate
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; 
                else: ?>
                    <tr><td colspan="4" style="padding: 40px; text-align: center; color: #999;">No active employees found in the system.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div id="ratingModal" style="display:none; position: fixed; z-index: 9999; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); backdrop-filter: blur(3px);">
    <div style="background: white; margin: 8% auto; padding: 35px; width: 400px; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.2);">
        <h3 style="color: #003b46; margin-bottom: 20px; text-align: center;">Quick Performance Rating</h3>
        <form action="index.php?page=process_appraisal" method="POST">
            <label style="display:block; margin-bottom: 8px; font-size: 13px; font-weight: 600; color: #555;">Target Employee</label>
            <select name="emp_id" required style="width: 100%; padding: 12px; margin-bottom: 20px; border: 1px solid #ddd; border-radius: 8px; font-family: inherit;">
                <option value="" disabled selected>Choose from your team...</option>
                <?php
                $emp_list = $conn->query("SELECT User_ID, Full_Name FROM user_account WHERE Role = 'Employee'");
                while($e = $emp_list->fetch_assoc()) {
                    echo "<option value='{$e['User_ID']}'>".htmlspecialchars($e['Full_Name'])."</option>";
                }
                ?>
            </select>

            <label style="display:block; margin-bottom: 8px; font-size: 13px; font-weight: 600; color: #555;">Performance Score (1.0 - 5.0)</label>
            <input type="number" name="score" step="0.1" min="1" max="5" required placeholder="e.g. 4.5" 
                   style="width: 100%; padding: 12px; margin-bottom: 25px; border: 1px solid #ddd; border-radius: 8px; box-sizing: border-box; font-family: inherit;">

            <div style="display: flex; gap: 12px;">
                <button type="submit" style="flex: 2; background: #003b46; color: white; border: none; padding: 14px; border-radius: 8px; cursor: pointer; font-weight: bold; font-family: inherit;">Submit Appraisal</button>
                <button type="button" onclick="document.getElementById('ratingModal').style.display='none'" 
                        style="flex: 1; background: #f4f4f4; border: none; padding: 14px; border-radius: 8px; cursor: pointer; color: #666; font-family: inherit;">Cancel</button>
            </div>
        </form>
    </div>
</div>

<div id="achievementModal" style="display:none; position: fixed; z-index: 9999; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); backdrop-filter: blur(3px);">
    <div style="background: white; margin: 8% auto; padding: 35px; width: 450px; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.2);">
        <h3 style="color: #07575b; margin-bottom: 20px; text-align: center;">🏆 Award Career Achievement</h3>
        <form action="index.php?page=process_achievement" method="POST">
            <label style="display:block; margin-bottom: 8px; font-size: 13px; font-weight: 600; color: #555;">Recipient</label>
            <select name="emp_id" required style="width: 100%; padding: 12px; margin-bottom: 20px; border: 1px solid #ddd; border-radius: 8px; font-family: inherit;">
                <option value="" disabled selected>Who earned this award?</option>
                <?php
                $emp_list = $conn->query("SELECT User_ID, Full_Name FROM user_account WHERE Role = 'Employee'");
                while($emp = $emp_list->fetch_assoc()) {
                    echo "<option value='{$emp['User_ID']}'>".htmlspecialchars($emp['Full_Name'])."</option>";
                }
                ?>
            </select>

            <label style="display:block; margin-bottom: 8px; font-size: 13px; font-weight: 600; color: #555;">Achievement Citation</label>
            <textarea name="description" placeholder="e.g. Outstanding leadership during the Q1 product launch..." required 
                      style="width: 100%; padding: 12px; margin-bottom: 25px; border: 1px solid #ddd; border-radius: 8px; height: 100px; resize: none; box-sizing: border-box; font-family: inherit;"></textarea>

            <div style="display: flex; gap: 12px;">
                <button type="submit" style="flex: 2; background: #07575b; color: white; border: none; padding: 14px; border-radius: 8px; cursor: pointer; font-weight: bold; font-family: inherit;">Give Award</button>
                <button type="button" onclick="document.getElementById('achievementModal').style.display='none'" 
                        style="flex: 1; background: #f4f4f4; border: none; padding: 14px; border-radius: 8px; cursor: pointer; color: #666; font-family: inherit;">Cancel</button>
            </div>
        </form>
    </div>
</div>