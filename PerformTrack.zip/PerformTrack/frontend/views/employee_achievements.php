<div class="main-content" style="padding: 40px; font-family: 'Poppins';">
    <header style="margin-bottom: 30px;">
        <h1 style="color: #003b46;">🏆 My Achievements</h1>
        <p style="color: #666;">A record of your hard work and recognized milestones.</p>
    </header>

    <div class="achievements-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px;">
        <?php
        $user_id = $_SESSION['user_id'];
        
        $query = "SELECT * FROM achievement WHERE Employee_ID = $user_id ORDER BY Achievement_Date DESC";
        $result = $conn->query($query);

        if ($result && $result->num_rows > 0):
            while($row = $result->fetch_assoc()): ?>
            <div class="achievement-card" style="background: white; padding: 20px; border-radius: 15px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); border-top: 5px solid #07575b;">
                <h3 style="color: #003b46; margin-bottom: 10px;">Recognition Milestone</h3>
                
                <p style="color: #666; font-size: 14px; margin-bottom: 15px;">
                    <?php echo htmlspecialchars($row['Description']); ?>
                </p>
                
                <span style="font-size: 12px; color: #999;">
                    Earned on: <?php
                        if (!empty($row['Achievement_Date']) && strtotime($row['Achievement_Date'])) {
                            echo date('M d, Y', strtotime($row['Achievement_Date'])); 
                        } else {
                            echo "Date not recorded";
                        }
                    ?>
                </span>
            </div>
            <?php endwhile; 
        else: ?>
            <div style="grid-column: 1/-1; text-align: center; padding: 50px; background: white; border-radius: 15px; color: #999;">
                <p>No achievements recorded yet. Keep up the great work!</p>
            </div>
        <?php endif; ?>
    </div>
</div>