<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = new mysqli("localhost", "root", "", "performtrack");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT User_ID, UserName, Role, Password FROM user_account WHERE UserName = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        if ($password === $user['Password']) {
            $_SESSION['user_id'] = $user['User_ID'];
            $_SESSION['username'] = $user['UserName'];
            $_SESSION['role'] = $user['Role'];

            header("Location: index.php?page=dashboard");
            exit();
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "User not found.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PerformTrack - Login</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body>
    <div class="login-page">
        <div class="login-box">
            <h1>PerformTrack</h1>
            
            <?php if(isset($error)): ?>
                <div class="error-box" style="display: block;"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form method="POST" action="index.php?page=login">
                <div class="input-group">
                    <span class="icon-left">👤</span>
                    <input type="text" name="username" placeholder="Username" required>
                </div>

                <div class="input-group">
                    <span class="icon-left">🔒</span>
                    <input type="password" name="password" placeholder="Password" required>
                </div>

                <button type="submit">Login</button>
            </form>

            <div class="divider">OR</div>
            
            <div class="google-btn">
                <img src="https://www.gstatic.com/images/branding/product/1x/gsa_512dp.png" class="google-logo" alt="G">
                Continue with Google
            </div>

            <p class="create-account" onclick="location.href='index.php?page=register'">
                Don't have an account? <strong>Register here.</strong>
            </p>
        </div>
    </div>
</body>
</html>