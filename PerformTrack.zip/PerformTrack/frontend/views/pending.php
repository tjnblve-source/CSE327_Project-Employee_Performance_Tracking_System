<div class="main-content" style="padding: 40px; font-family: 'Poppins';">
    <header style="margin-bottom: 30px;">
        <h1 style="color: #003b46;">📝 Pending Appraisals</h1>
        <p style="color: #666;">Employees awaiting their performance review for this period.</p>
    </header>

    <div class="table-card" style="background: white; padding: 25px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.05);">
        <table style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr style="text-align: left; border-bottom: 2px solid #f4f4f4;">
                    <th style="padding: 15px;">Employee</th>
                    <th style="padding: 15px;">Status</th>
                    <th style="padding: 15px;">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $current_month = date('F Y');
                $query = "SELECT User_ID, Full_Name FROM user_account 
                          WHERE Role = 'Employee' 
                          AND User_ID NOT IN (SELECT Employee_ID FROM appraisal WHERE Review_Period = '$current_month')";
                
                $result = $conn->query($query);

                if ($result && $result->num_rows > 0):
                    while($row = $result->fetch_assoc()): ?>
                    <tr style="border-bottom: 1px solid #f9f9f9;">
                        <td style="padding: 15px;">
                            <strong><?php echo $row['Full_Name']; ?></strong><br>
                            <span style="font-size: 12px; color: #999;">ID: #<?php echo $row['User_ID']; ?></span>
                        </td>
                        <td style="padding: 15px;">
                            <span style="background: #fff4e5; color: #b05d06; padding: 5px 12px; border-radius: 20px; font-size: 12px; font-weight: bold;">Pending</span>
                        </td>
                        <td style="padding: 15px;">
                            <a href="index.php?page=appraisal_form&id=<?php echo $row['User_ID']; ?>" style="background: #07575b; color: white; padding: 8px 15px; border-radius: 5px; text-decoration: none; font-size: 14px;">Start Review</a>
                        </td>
                    </tr>
                    <?php endwhile; 
                else: ?>
                    <tr>
                        <td colspan="3" style="padding: 30px; text-align: center; color: #28a745; font-weight: bold;">
                            ✅ All appraisals are up to date!
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>