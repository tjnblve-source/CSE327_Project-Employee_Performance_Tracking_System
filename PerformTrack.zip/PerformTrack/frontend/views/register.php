<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PerformTrack - Create Account</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body>
    <div class="login-page">
        <div class="login-box">
            <h1>Join PerformTrack</h1>
            <p style="color: white; margin-bottom: 30px; opacity: 0.8;">Select your role and create your profile</p>
            
            <?php if(isset($error)): ?>
                <div class="error-box" style="display: block;"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form method="POST" action="index.php?page=process_registration">
                <div class="input-group">
                    <span class="icon-left">👤</span>
                    <input type="text" name="full_name" placeholder="Full Name" required>
                </div>

                <div class="input-group">
                    <span class="icon-left">📧</span>
                    <input type="email" name="email" placeholder="Email Address" required>
                </div>

                <div class="input-group">
                    <span class="icon-left">🆔</span>
                    <input type="text" name="username" placeholder="Choose Username" required>
                </div>
]
                <div class="input-group">
                    <span class="icon-left">💼</span>
                    <select name="role" required style="width:100%; padding:15px 60px; border:none; border-radius:50px; background:rgba(255,255,255,0.25); font-size:16px; color:white; outline:none; appearance: none;">
                        <option value="" disabled selected style="color: black;">Select Your Role</option>
                        <option value="Employee" style="color: black;">Employee</option>
                        <option value="Manager" style="color: black;">Manager</option>
                        <option value="HR Admin" style="color: black;">HR Admin</option>
                    </select>
                </div>

                <div class="input-group">
                    <span class="icon-left">🔒</span>
                    <input type="password" name="password" placeholder="Create Password" required>
                </div>

                <button type="submit" class="btn-submit">Register Now</button>
            </form>

            <a href="index.php?page=login" class="create-account">Already have an account? Login here</a>
        </div>
    </div>
</body>
</html>