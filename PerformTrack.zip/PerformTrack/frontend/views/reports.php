<div class="main-content" style="padding: 40px; font-family: 'Poppins';">
    <header style="margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center;">
        <div>
            <h1 style="color: #003b46; margin: 0;">📊 Performance Reports</h1>
            <p style="color: #666;">Comprehensive overview of team evaluations and scores.</p>
        </div>
        <button onclick="window.print()" style="background: #07575b; color: white; padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer;">Print Report</button>
    </header>

    <div class="stats-grid" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 30px;">
        <div class="stat-card" style="background: white; padding: 20px; border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); text-align: center;">
            <h4 style="color: #666; margin-bottom: 10px;">Average Team Score</h4>
            <?php
            $avg_res = $conn->query("SELECT AVG(Final_Score) as team_avg FROM appraisal");
            $avg_data = $avg_res->fetch_assoc();
            echo "<p style='font-size: 28px; font-weight: bold; color: #003b46;'>" . number_format($avg_data['team_avg'], 2) . " / 5.0</p>";
            ?>
        </div>
    </div>

    <div class="table-card" style="background: white; padding: 25px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.05);">
        <table style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr style="text-align: left; border-bottom: 2px solid #f4f4f4;">
                    <th style="padding: 15px;">Employee Name</th>
                    <th style="padding: 15px;">Review Period</th>
                    <th style="padding: 15px;">Rating</th>
                    <th style="padding: 15px;">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = "SELECT a.Final_Score, a.Review_Period, u.Full_Name 
                          FROM appraisal a 
                          JOIN user_account u ON a.Employee_ID = u.User_ID 
                          ORDER BY a.Appraisal_ID DESC";
                
                $result = $conn->query($query);

                if ($result && $result->num_rows > 0):
                    while($row = $result->fetch_assoc()): ?>
                    <tr style="border-bottom: 1px solid #f9f9f9;">
                        <td style="padding: 15px; font-weight: 600;"><?php echo $row['Full_Name']; ?></td>
                        <td style="padding: 15px; color: #666;"><?php echo $row['Review_Period']; ?></td>
                        <td style="padding: 15px;">
                            <strong style="color: #07575b;"><?php echo $row['Final_Score']; ?></strong> / 5.0
                        </td>
                        <td style="padding: 15px;">
                            <span style="background: #e6f4ea; color: #1e7e34; padding: 5px 12px; border-radius: 20px; font-size: 12px; font-weight: bold;">Completed</span>
                        </td>
                    </tr>
                    <?php endwhile; 
                else: ?>
                    <tr><td colspan="4" style="padding: 30px; text-align: center; color: #999;">No performance data available yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>