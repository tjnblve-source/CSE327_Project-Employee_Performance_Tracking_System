-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2026 at 05:38 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `performtrack`
--

-- --------------------------------------------------------

--
-- Table structure for table `achievement`
--

CREATE TABLE `achievement` (
  `Achievement_ID` int(11) NOT NULL,
  `Employee_ID` int(11) NOT NULL,
  `Achievement_Date` date DEFAULT NULL,
  `Description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `achievement`
--

INSERT INTO `achievement` (`Achievement_ID`, `Employee_ID`, `Achievement_Date`, `Description`) VALUES
(2, 6, NULL, 'Employee of the Month'),
(3, 5, NULL, 'Y'),
(4, 7, NULL, 'fhffh'),
(5, 3, NULL, 'f'),
(7, 3, NULL, 'Outstanding performance.');

-- --------------------------------------------------------

--
-- Table structure for table `appraisal`
--

CREATE TABLE `appraisal` (
  `Appraisal_ID` int(11) NOT NULL,
  `Employee_ID` int(11) NOT NULL,
  `Final_Score` decimal(3,2) DEFAULT NULL,
  `Review_Period` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appraisal`
--

INSERT INTO `appraisal` (`Appraisal_ID`, `Employee_ID`, `Final_Score`, `Review_Period`) VALUES
(3, 3, 4.00, 'May 2026'),
(4, 5, 1.30, 'May 2026'),
(5, 6, 5.00, 'May 2026'),
(6, 3, 2.00, 'May 2026'),
(7, 3, 2.00, 'May 2026'),
(8, 5, 3.00, 'May 2026'),
(9, 5, 3.00, 'May 2026'),
(10, 3, 2.00, 'May 2026'),
(11, 8, 5.00, 'May 2026'),
(12, 5, 4.00, 'May 2026'),
(13, 7, 5.00, 'May 2026'),
(14, 7, 5.00, 'May 2026'),
(15, 6, 3.00, 'May 2026'),
(16, 3, 4.00, 'May 2026'),
(17, 6, 5.00, 'May 2026'),
(18, 3, 2.20, 'May 2026');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `Attendance_ID` int(11) NOT NULL,
  `Employee_ID` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Status` enum('Present','Absent','Late','Leave') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `Department_ID` int(11) NOT NULL,
  `Department_Name` varchar(100) NOT NULL,
  `Manager_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `Employee_ID` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Phone` varchar(15) DEFAULT NULL,
  `Department_ID` int(11) DEFAULT NULL,
  `Manager_ID` int(11) DEFAULT NULL,
  `Job_Title` varchar(100) DEFAULT NULL,
  `Joining_Date` date NOT NULL,
  `Promotion_Eligibility_Status` tinyint(1) DEFAULT 0,
  `Attendance_Percentage` decimal(5,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Employee_ID`, `Name`, `Email`, `Phone`, `Department_ID`, `Manager_ID`, `Job_Title`, `Joining_Date`, `Promotion_Eligibility_Status`, `Attendance_Percentage`) VALUES
(3, 'Employee1', 'emp1@gmail.com', NULL, NULL, NULL, NULL, '0000-00-00', 0, 85.00),
(5, 'Employee2', 'emp2@gmail.com', NULL, NULL, NULL, NULL, '2026-05-05', 0, 85.00),
(6, 'Employee3', 'emp3@gmail.com', NULL, NULL, NULL, NULL, '2026-05-05', 0, 95.00),
(7, 'Employee4', 'emp4@gmail.com', NULL, NULL, NULL, NULL, '2026-05-05', 0, 90.00),
(8, 'Employee5', 'emp5@gmail.com', NULL, NULL, NULL, NULL, '2026-05-05', 0, 85.00),
(23, 'Employee6', 'emp6@gmail.comq', NULL, NULL, NULL, NULL, '2026-05-05', 0, 100.00),
(25, 'Employee7', 'emp7@gmail.com', NULL, NULL, NULL, NULL, '2026-05-05', 0, 100.00);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `Feedback_ID` int(11) NOT NULL,
  `Appraisal_ID` int(11) NOT NULL,
  `Manager_ID` int(11) NOT NULL,
  `Comments` text DEFAULT NULL,
  `Rating_Value` int(11) DEFAULT NULL CHECK (`Rating_Value` between 1 and 5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hr_admin`
--

CREATE TABLE `hr_admin` (
  `HR_ID` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Phone` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `Manager_ID` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Phone` varchar(15) DEFAULT NULL,
  `Department_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `Notification_ID` int(11) NOT NULL,
  `Employee_ID` int(11) DEFAULT NULL,
  `Message` text DEFAULT NULL,
  `Is_Read` tinyint(1) DEFAULT 0,
  `Created_At` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`Notification_ID`, `Employee_ID`, `Message`, `Is_Read`, `Created_At`) VALUES
(1, 6, 'Congratulations! You have been promoted.', 0, '2026-05-04 19:38:33');

-- --------------------------------------------------------

--
-- Table structure for table `promotion`
--

CREATE TABLE `promotion` (
  `Promotion_ID` int(11) NOT NULL,
  `Employee_ID` int(11) NOT NULL,
  `Old_Role` varchar(100) DEFAULT NULL,
  `New_Role` varchar(100) DEFAULT NULL,
  `Approval_Status` enum('Pending','Approved','Rejected') DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `Report_ID` int(11) NOT NULL,
  `Employee_ID` int(11) NOT NULL,
  `Generated_By` int(11) NOT NULL,
  `Time_Stamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `Average_Rating` decimal(3,2) DEFAULT NULL,
  `Total_Achievements` int(11) DEFAULT NULL,
  `Attendance_Percentage` decimal(5,2) DEFAULT NULL,
  `Promotion_Recommendation` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_account`
--

CREATE TABLE `user_account` (
  `User_ID` int(11) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `Full_Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Phone` char(11) DEFAULT NULL,
  `Password` varchar(255) NOT NULL,
  `Role` enum('Employee','Manager','HR Admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_account`
--

INSERT INTO `user_account` (`User_ID`, `UserName`, `Full_Name`, `Email`, `Phone`, `Password`, `Role`) VALUES
(1, 'hr1', 'HR1', 'hr1@gmail.com', NULL, 'hr1', 'HR Admin'),
(3, 'emp1', 'Employee1', 'emp1@gmail.com', NULL, 'emp1', 'Employee'),
(4, 'man1', 'Manager1', 'man1@gmail.come', NULL, 'man1', 'Manager'),
(5, 'emp2', 'Employee2', 'emp2@gmail.com', NULL, 'emp2', 'Employee'),
(6, 'emp3', 'Employee3', 'emp3@gmail.com', NULL, 'emp3', ''),
(7, 'emp4', 'Employee4', 'emp4@gmail.com', NULL, 'emp4', ''),
(8, 'emp5', 'Employee5', 'emp5@gmail.com', NULL, 'emp5', 'Employee'),
(9, 'hr2', 'HR2', 'hr2@gmail.com', NULL, 'hr2', 'HR Admin'),
(10, 'man2', 'Manager2', 'man2@gmail.com', NULL, 'man2', 'Manager'),
(23, 'emp6', 'Employee6', 'emp6@gmail.comq', NULL, '$2y$10$ABojoDJSo4bzlyluNUdV2OFpLXm1wrdL4pQTFcUkg7.N194ee3jeO', 'Employee'),
(24, 'man3', 'Manager3', 'man3@gmail.com', NULL, '$2y$10$92NURTqtk0kJhuOFI2bmwu2P5GYdV6TDITAtDEB4elgIwyYb7OK3S', 'Manager'),
(25, 'emp7', 'Employee7', 'emp7@gmail.com', NULL, '$2y$10$vZrX9V2hCXUFzPfsFvwFPO2XPNwDXuCspe2/RusN329LCZWO4TKQq', 'Employee');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `achievement`
--
ALTER TABLE `achievement`
  ADD PRIMARY KEY (`Achievement_ID`),
  ADD KEY `fk_user_achievement` (`Employee_ID`);

--
-- Indexes for table `appraisal`
--
ALTER TABLE `appraisal`
  ADD PRIMARY KEY (`Appraisal_ID`),
  ADD KEY `fk_user_appraisal` (`Employee_ID`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`Attendance_ID`),
  ADD KEY `Employee_ID` (`Employee_ID`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`Department_ID`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`Employee_ID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD KEY `Department_ID` (`Department_ID`),
  ADD KEY `Manager_ID` (`Manager_ID`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`Feedback_ID`),
  ADD KEY `Appraisal_ID` (`Appraisal_ID`),
  ADD KEY `Manager_ID` (`Manager_ID`);

--
-- Indexes for table `hr_admin`
--
ALTER TABLE `hr_admin`
  ADD PRIMARY KEY (`HR_ID`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`Manager_ID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD KEY `Department_ID` (`Department_ID`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`Notification_ID`),
  ADD KEY `Employee_ID` (`Employee_ID`);

--
-- Indexes for table `promotion`
--
ALTER TABLE `promotion`
  ADD PRIMARY KEY (`Promotion_ID`),
  ADD KEY `Employee_ID` (`Employee_ID`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`Report_ID`),
  ADD KEY `Employee_ID` (`Employee_ID`),
  ADD KEY `Generated_By` (`Generated_By`);

--
-- Indexes for table `user_account`
--
ALTER TABLE `user_account`
  ADD PRIMARY KEY (`User_ID`),
  ADD UNIQUE KEY `UserName` (`UserName`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `achievement`
--
ALTER TABLE `achievement`
  MODIFY `Achievement_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `appraisal`
--
ALTER TABLE `appraisal`
  MODIFY `Appraisal_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `Attendance_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `Department_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `Feedback_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `Notification_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `promotion`
--
ALTER TABLE `promotion`
  MODIFY `Promotion_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `Report_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_account`
--
ALTER TABLE `user_account`
  MODIFY `User_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `achievement`
--
ALTER TABLE `achievement`
  ADD CONSTRAINT `fk_user_achievement` FOREIGN KEY (`Employee_ID`) REFERENCES `user_account` (`User_ID`) ON DELETE CASCADE;

--
-- Constraints for table `appraisal`
--
ALTER TABLE `appraisal`
  ADD CONSTRAINT `fk_user_appraisal` FOREIGN KEY (`Employee_ID`) REFERENCES `user_account` (`User_ID`) ON DELETE CASCADE;

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`Employee_ID`) REFERENCES `employee` (`Employee_ID`) ON DELETE CASCADE;

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`Employee_ID`) REFERENCES `user_account` (`User_ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `employee_ibfk_2` FOREIGN KEY (`Department_ID`) REFERENCES `department` (`Department_ID`),
  ADD CONSTRAINT `employee_ibfk_3` FOREIGN KEY (`Manager_ID`) REFERENCES `manager` (`Manager_ID`);

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`Appraisal_ID`) REFERENCES `appraisal` (`Appraisal_ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `feedback_ibfk_2` FOREIGN KEY (`Manager_ID`) REFERENCES `manager` (`Manager_ID`);

--
-- Constraints for table `hr_admin`
--
ALTER TABLE `hr_admin`
  ADD CONSTRAINT `hr_admin_ibfk_1` FOREIGN KEY (`HR_ID`) REFERENCES `user_account` (`User_ID`) ON DELETE CASCADE;

--
-- Constraints for table `manager`
--
ALTER TABLE `manager`
  ADD CONSTRAINT `manager_ibfk_1` FOREIGN KEY (`Manager_ID`) REFERENCES `user_account` (`User_ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `manager_ibfk_2` FOREIGN KEY (`Department_ID`) REFERENCES `department` (`Department_ID`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`Employee_ID`) REFERENCES `employee` (`Employee_ID`);

--
-- Constraints for table `promotion`
--
ALTER TABLE `promotion`
  ADD CONSTRAINT `promotion_ibfk_1` FOREIGN KEY (`Employee_ID`) REFERENCES `employee` (`Employee_ID`) ON DELETE CASCADE;

--
-- Constraints for table `report`
--
ALTER TABLE `report`
  ADD CONSTRAINT `report_ibfk_1` FOREIGN KEY (`Employee_ID`) REFERENCES `employee` (`Employee_ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `report_ibfk_2` FOREIGN KEY (`Generated_By`) REFERENCES `user_account` (`User_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
